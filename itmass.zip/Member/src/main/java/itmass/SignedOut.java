package itmass;

public class SignedOut extends AbstractEvent {

    private Long id;
    private String memId;

    public SignedOut(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getMemId() {
        return memId;
    }

    public void setMemId(String memId) {
        this.memId = memId;
    }
}
